# Changelog

All notable changes to Eversolo Screen Control are documented here.

Version numbering follows [Semantic Versioning](https://semver.org/):

    MAJOR.MINOR.PATCH

    PATCH  (1.0.x)  — Bug fixes, minor corrections, no new behaviour
    MINOR  (1.x.0)  — New features, new settings, backwards-compatible
    MAJOR  (x.0.0)  — Breaking changes (e.g. renamed prefs, restructured config)

---

## [2.3.2] — 2026-09-30

Everything since 2.2.1. The Eversolo can now be switched back **on** from LMS.
Until now power control was one-way: once the device was off, its player left
LMS and took the power button with it. A small power page, reachable from a tile
on Material's Home screen, needs no player and works either way.

### New Features
- **An Eversolo power page, and a tile for it on Material's Home screen.** One
  card per Eversolo, showing whether it is on, with a single button to switch
  it on or off.
  - **Opt-in, per player.** Tick **Power button on Material's Home screen** in
    the player's Eversolo settings. It also needs **Enable Eversolo Screen
    Control** and **Control Eversolo power** ticked, and the device's address
    filled in. Refresh Material after saving and an **Eversolo Power** tile is
    offered for the Home screen.
  - **Switching on is Wake-on-LAN**, which the Eversolo only accepts on its
    **wired** network port, from a server on the same subnet. Over Wi-Fi it
    will not come back on.
  - **The device's MAC address is learned while it is on.** Open the player's
    Eversolo settings once with the device switched on before relying on the
    page to wake it; the page says so when it cannot wake a device yet.
  - **Switching off takes two taps** — the first arms the button for four
    seconds — so a stray tap cannot shut the device down.
  - **The page and the player's own power button agree.** Press either and the
    page shows *Switching on…* or *Switching off…* until the device answers,
    rather than the old state for the length of a boot.
  - Unticking the box stops the tile being offered. A tile already on your Home
    screen stays until you unpin it from its own menu; the same is true after
    uninstalling the plugin, because Material keeps the Home screen in the
    browser.
  - The page also works in any browser at `http://<server>:9000/eversolopower`.

### Bug Fixes
- A new player's settings page now shows the 30-second screen-off delay and
  port 9529. The per-player defaults were never saved, so both boxes were empty
  until the first save — the plugin itself always fell back to the same values.
- Powering an Eversolo off no longer leaves a second player on the same device
  trying to switch its screen off a minute later, a request that could only fail
  and logged an error that read like a fault.
- A Wake-on-LAN packet that failed to send is now logged, rather than treated as
  sent.
- A player that LMS forgot while its screen was waiting to switch off — LMS does
  this by itself five minutes after a player disconnects — no longer stops the
  once-a-minute check from switching that screen off after it reconnects.

---

## [2.2.1] — 2026-09-11

Docs only — no plugin code changed.

### Documentation
- `README.md` moved out of `EversoloScreenControl/` to the repo root, as the
  single source for the generated docs page. Regenerated `README.html` and
  `index.html` in the house style via `tools/make_readme_html.py`, picking up
  the 2.2.1 version badge.
- `README.md` is no longer shipped inside `EversoloScreenControl.zip`.
- Wake-on-LAN remains deliberately undocumented: once the Eversolo powers off,
  its LMS player disappears, so there is no button left in LMS to wake it with.
  The WoL code and `tools/t_power.pl` are unchanged.

---

## [2.2.0] — 2026-09-10

Everything below has accumulated since 1.0.3. The plugin gained the ability to
power the Eversolo on and off, learned to work with players fed through a
bridge, and stopped taking the server's word for what is playing.

### New Features
- **Power the Eversolo on and off from the player's power button.** Optional and
  off by default, per player, under **Control Eversolo power**. Powering off
  sends the same shutdown the Eversolo's own app sends. Powering on is a
  Wake-on-LAN magic packet, because the device is off and nothing is listening
  for anything else.
  - **Wake-on-LAN only works over the wired network port**, and the server has
    to be on the same subnet. Over Wi-Fi the Eversolo will power down and not
    come back. Eversolo document this themselves.
  - The device's MAC address can only be read while it is **on**, so the
    settings page reads it as soon as an address is entered and says so plainly
    while it is still unknown. Tick the box while the device is off and a
    power-off is a one-way trip until you switch it on by hand.
- **A synced group powers each of its own Eversolos.** Press power on one player
  of a sync group and every buddy set to follow it now drives its own device,
  using its own settings. A buddy with the plugin turned off is left alone.
- **The settings page identifies the device.** Type an address and the page asks
  the Eversolo who it is, then shows its name — `DMP-A8 (ManCave)` rather than an
  address echoed back at you. The port is configurable for anyone not on 9529.

### Changes
- **Players fed through a bridge or a virtual player now work.** The address is
  taken from the settings page and nowhere else. It used to fall back to the
  player's own address on the theory that the player might be running on the
  Eversolo itself, which is wrong for exactly the setups that need this most —
  a bridged player reports a placeholder address, so the screen commands went to
  the server rather than the device.
- **The screen is checked against the player, not just against events.** Every
  minute the plugin compares what each enabled player is doing against what it
  believes the screen is doing, and corrects a disagreement. A stop that the
  plugin never witnessed — one that happened across a server restart, or that a
  bridged player never announced — used to leave the screen on for ever with
  nothing able to put it right.
- **The Eversolo is asked directly when the server's state looks stuck.** A
  player can sit in "playing" with a frozen clock when the thing feeding it goes
  quiet, and the screen would follow it and stay on. When the clock stops moving
  the plugin asks the device what it is actually doing and believes the answer.
  This costs one request per stuck player and nothing at all in normal use.
- A device that does not answer is treated as **no opinion**, never as
  "stopped". A missed reply will not blank a screen mid-track.

### Bug Fixes
- Fixed: a reply from the Eversolo arriving late could act on a situation that
  had already passed — blanking a screen that playback had since turned back on,
  or acting for a player whose address had been changed underneath it. Replies
  are now matched to the state that asked for them and discarded otherwise.
- Fixed: the settings page could attach one device's name and Wake-on-LAN MAC to
  a different device's address if the address was changed while a lookup was
  still in flight.
- Fixed: the chosen port was not saved.
- Fixed: a screen-off timer created by the periodic check was not cancelled when
  the plugin shut down.
- Fixed: **Enabled** and **Control Eversolo power** could get into a state where
  they could not be switched off again. The page repairs an affected setting on
  the next view.

---

## [1.0.3] — 2026-07-06

### Bug Fixes
- Fixed: the per-player settings page rendered with all fields blank (a v1.0.2
  regression). v1.0.2 removed the block that populated the template's unprefixed
  `prefs.*` keys, on the mistaken assumption that `SUPER::handler` repopulates
  them. The LMS framework only fills the `pref_`-prefixed keys, which this
  template does not read, so every field came back empty/unchecked. The manual
  population has been restored.

---

## [1.0.2] — 2026-06-26

### Bug Fixes
- Fixed: with more than one Eversolo player, resuming playback on one player
  could cancel another player's pending screen-off timer (the timer was keyed
  by the MAC string, which `Slim::Utils::Timers` compares numerically, so all
  ids collided). Timers are now keyed by the client object.
- Fixed: a **Screen Off Delay** of `0` (immediate off) was treated as "unset"
  and silently became 30 seconds. A configured `0` is now honoured.

### Changes
- Narrowed the playback event subscription to play-state changes only, so
  read-only `playlist` queries no longer wake the callback.
- Removed an unused `SCANNER` log-group assignment from the log category.
- Removed redundant settings-page pref population (the framework already
  repopulates after save).
- Corrected the placeholder homepage URL in `install.xml`.

---

## [1.0.1] — 2026-06-05

### Bug Fixes
- Fixed: Plugin stopped working when the Eversolo's IP address changed via
  DHCP. The IP was stored once on first use and never updated.

### Changes
- Added **Auto-detect Eversolo IP** option (on by default). When enabled,
  the plugin reads the player's live IP via `$client->ip()` at the moment
  each command is sent, so it automatically follows DHCP changes.
- The manual IP field is now only used when auto-detect is unticked
  (for setups where the Eversolo is on a different address from the player).
- Settings page now shows the current live player IP for reference.

---

## [1.0.0] — 2026-06-02

Initial release.

### Features
- Per-player plugin — appears in Player Settings menu (like DSD Player)
- Enable/disable independently for each LMS player
- Sends `Key.Screen.ON` to Eversolo HTTP API when playback starts
- Re-sends `Key.Screen.ON` on every song change (`playlist newsong`) to
  reset the Eversolo's own screensaver timer during continuous playback
- Sends `Key.Screen.OFF` after a configurable delay when playback pauses
  or stops (default 30 seconds)
- Safety check: if playback resumes before the off-timer fires, the
  timer is cancelled and the screen stays on
- Auto-populates the Eversolo IP address from the player's IP on first
  use (since Squeezelite on the Eversolo shares the same IP)
- All HTTP calls are non-blocking (`Slim::Networking::SimpleAsyncHTTP`)
- Configurable per player: IP address, port, screen-off delay
- Eversolo brandmark icon for plugin list and Material skin
